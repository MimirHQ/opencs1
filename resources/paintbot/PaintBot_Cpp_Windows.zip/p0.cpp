#include <iostream>
#include "paintbot.h"
using namespace std;

/*
 * Player 0: Challenger
 */
int main() {
    start();
    forward();
    forward();
    forward();
    forward();
}