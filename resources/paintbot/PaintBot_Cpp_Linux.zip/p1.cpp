#include <iostream>
#include "paintbot.h"
using namespace std;

/*
 * Player 1: Opponent
 */
int main() {
    start();
    forward();
    forward();
    forward();
    forward();
}