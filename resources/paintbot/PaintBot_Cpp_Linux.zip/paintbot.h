/**
 * Game State Managers
 */

void updateBoardData();
void start();

/**
 * Movement
 */

void forward();
void backward();
void rotateLeft();
void rotateRight();
void skip();

/**
 * Sensors
 */

int getRotation();
int getX();
int getY();
int getXSize();
int getYSize();
bool isInBounds(int x, int y);
bool isBlocked(int x, int y);
bool isMyColor(int x, int y);

/**
 * Game Data
 */

int getMyScore();
int getTurn();
int getMaxTurns();
bool isPlaying();
