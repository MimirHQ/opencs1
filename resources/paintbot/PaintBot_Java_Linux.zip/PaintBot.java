import java.util.Scanner;

public class PaintBot {

    /**
     * Game State Managers
     */

    private static Scanner scanner = new Scanner(System.in);
    private static int myColor = 0;
    private static int xSize = 0;
    private static int ySize = 0;
    private static int xPos = 0;
    private static int yPos = 0;
    private static int rotation = 0;
    private static int turn = 0;
    private static int maxTurns = 0;
    private static int myScore = 0;
    private static String[] board;

    protected static void updateBoardData() {
        System.out.println("cmd:get_board_data");
        myColor = Integer.parseInt(scanner.nextLine());
        xSize = Integer.parseInt(scanner.nextLine());;
        ySize = Integer.parseInt(scanner.nextLine());;
        xPos = Integer.parseInt(scanner.nextLine());;
        yPos = Integer.parseInt(scanner.nextLine());;
        rotation = Integer.parseInt(scanner.nextLine());;
        turn = Integer.parseInt(scanner.nextLine());;
        maxTurns = Integer.parseInt(scanner.nextLine());;
        myScore = Integer.parseInt(scanner.nextLine());;
        String data = scanner.nextLine();
        board = data.split(",");
    }

    protected static void start() {
        System.out.println("cmd:start");
        updateBoardData();
    }

    /**
     * Movement
     */

    protected static void forward() {
        System.out.println("cmd:forward");
        updateBoardData();

    }

    protected static void backward() {
        System.out.println("cmd:backward");
        updateBoardData();

    }

    protected static void rotateLeft() {
        System.out.println("cmd:rotate_left");
        int newRotation = rotation - 90;
        if (newRotation < 0) {
            newRotation = newRotation + 360;
        }
        rotation = newRotation;
    }

    protected static void rotateRight() {
        System.out.println("cmd:rotate_right");
        int newRotation = (rotation + 90) % 360;
        rotation = newRotation;
    }

    protected static void skip() {
        System.out.println("cmd:skip");
        updateBoardData();

    }

    /**
     * Sensors
     */

    protected static int getRotation() {
        return rotation;
    }

    protected static int getX() {
        return xPos;
    }

    protected static int getY() {
        return yPos;
    }

    protected static int getXSize() {
        return xSize;
    }

    protected static int getYSize() {
        return ySize;
    }

    protected static boolean isInBounds(int x, int y) {
        boolean xIn = (x >= 0 && x < xSize);
        boolean yIn = (y >= 0 && y < ySize);
        return xIn && yIn;
    }

    protected static boolean isBlocked(int x, int y) {
        if (isInBounds(x, y)) {
            int index = (y * xSize) + x;
            boolean missing = board[index].equals("x");
            boolean occupied = board[index].charAt(0) == '^';
            return missing || occupied;
        }
        return false;
    }

    protected static boolean isMyColor(int x, int y) {
        if (isInBounds(x, y)) {
            int index = (y * xSize) + x;
            String mc = myColor + "";
            String mc_occupied = "^" + mc;
            return board[index].equals(mc) || board[index].equals(mc_occupied);
        }
        return false;
    }

    /**
     * Game Data
     */

    protected static int getMyScore() {
        return myScore;
    }

    protected static int getTurn() {
        return turn;
    }

    protected static int getMaxTurns() {
        return maxTurns;
    }

    protected static boolean isPlaying() {
        return getTurn() < getMaxTurns();
    }

}
