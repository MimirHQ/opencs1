public class P1 extends PaintBot {

    public static void main(String[] args) {
        start();
        forward();
        forward();
        forward();
    }

}