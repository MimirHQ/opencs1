#include <iostream>
#include <vector>
#include "paintbot.h"
using namespace std;

/**
 * Game State Managers
 */

vector<string> splitByComma(string text) {
    vector<string> data;
    string chunk = "";
    for (int i = 0; i < text.length(); i++) {
        char c = text[i];
        if (c == ',') {
            data.push_back(chunk);
            chunk = "";
        } else {
            chunk += c;
        }
    }
    data.push_back(chunk);
    return data;
}

int _myColor = 0;
int _xSize = 0;
int _ySize = 0;
int _xPos = 0;
int _yPos = 0;
int _rotation = 0;
int _turn = 0;
int _maxTurns = 0;
int _myScore = 0;
vector<string> _board;

void updateBoardData() {
    cout << "cmd:get_board_data" << endl;
    cin >> _myColor;
    cin >> _xSize;
    cin >> _ySize;
    cin >> _xPos;
    cin >> _yPos;
    cin >> _rotation;
    cin >> _turn;
    cin >> _maxTurns;
    cin >> _myScore;
    string data;
    cin >> data;
    _board = splitByComma(data);
}

void start() {
    cout << "cmd:start" << endl;
    updateBoardData();
}

/**
 * Movement
 */

void forward() {
    cout << "cmd:forward" << endl;
    updateBoardData();

}

void backward() {
    cout << "cmd:backward" << endl;
    updateBoardData();

}

void rotateLeft() {
    cout << "cmd:rotate_left" << endl;
    int newRotation = _rotation - 90;
    if (newRotation < 0) {
        newRotation = newRotation + 360;
    }
    _rotation = newRotation;
}

void rotateRight() {
    cout << "cmd:rotate_right" << endl;
    int newRotation = (_rotation + 90) % 360;
    _rotation = newRotation;
}

void skip() {
    cout << "cmd:skip" << endl;
    updateBoardData();

}

/**
 * Sensors
 */

int getRotation() {
    return _rotation;
}

int getX() {
    return _xPos;
}

int getY() {
    return _yPos;
}

int getXSize() {
    return _xSize;
}

int getYSize() {
    return _ySize;
}

bool isInBounds(int x, int y) {
    bool xIn = (x >= 0 && x < _xSize);
    bool yIn = (y >= 0 && y < _ySize);
    return xIn && yIn;
}

bool isBlocked(int x, int y) {
    if (isInBounds(x, y)) {
        int index = (y * _xSize) + x;
        bool missing = _board[index] == "x";
        bool occupied = _board[index][0] == '^';
        return missing || occupied;
    }
    return false;
}

bool isMyColor(int x, int y) {
    if (isInBounds(x, y)) {
        int index = (y * _xSize) + x;
        string mc = to_string(_myColor);
        string mc_occupied = "^" + mc;
        return _board[index] == mc || _board[index] == mc_occupied;
    }
    return false;
}

/**
 * Game Data
 */

int getMyScore() {
    return _myScore;
}

int getTurn() {
    return _turn;
}

int getMaxTurns() {
    return _maxTurns;
}

bool isPlaying() {
    return getTurn() < getMaxTurns();
}
