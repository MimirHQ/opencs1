"""
Main Game Client Class
"""
from paintbot.bot import PaintBot
from threading import Thread, Event
from time import time
from sys import exit

OPEN_CELL = "."
MISSING_CELL = "_"


class PaintGame:
    """TODO need a docstring here"""

    board = None
    players = []  # type: ignore
    move_flag = Event()
    max_turns = None
    bot_timelimit = None
    record = ""

    def __init__(self, x_size=5, y_size=5, max_turns=25, bot_timelimit=5, board=None):
        if x_size < 1:
            raise Exception("Board x size must be greater than 0.")
        if y_size < 1:
            raise Exception("Board y size must be greater than 0.")
        if max_turns < 1:
            raise Exception("Game turn limit must be greater than 0.")
        if board is None:
            board = []
            for y in range(y_size):
                row = []
                for x in range(x_size):
                    row.append(OPEN_CELL)
                board.append(row)
        self.board = board
        self.max_turns = max_turns
        self.bot_timelimit = bot_timelimit
        self.record = str(len(board[0])) + "," + str(len(board))

    def add_player(self, main_fn, pos=[0, 0], rotation=0):
        game = self
        pid = len(self.players)
        bot = PaintBot(game, pid, rotation)
        thread = Thread(
            name=("Player %d" % pid), target=main_fn, args=(bot,), daemon=True
        )
        self.players.append(
            {
                "pid": pid,
                "bot": bot,
                "thread": thread,
                "is_playing": True,
                "position": pos,
                "turn": 0,
                "move": None,
                "did_move": False,
                "move_failed": False,
                "rotation_log": str(bot.get_rotation()),
            }
        )
        if not self.is_in_bounds(pos[0], pos[1]):
            raise Exception(
                "Tried to add player {} out of bounds. ({}, {})".format(
                    pid, pos[0], pos[1]
                )
            )
        cell = self.board[pos[1]][pos[0]]
        if cell is not OPEN_CELL:
            raise Exception(
                "Tried to add player {} at occupied cell. ({}, {})".format(
                    pid, pos[0], pos[1]
                )
            )
        self.board[pos[1]][pos[0]] = str(pid)
        return pid

    def start(self):
        # Validate game board
        for y, row in enumerate(self.board):
            for x, cell in enumerate(row):
                if not self.is_valid_cell(cell):
                    invalid_cell_msg = "Entered an invalid cell at ({}, {}) = {}"
                    raise Exception(invalid_cell_msg.format(x, y, cell))
        # Initialize game and player threads
        self.move_flag.clear()
        self.update_record([p["position"] for p in self.players])
        for player in self.players:
            thread = player["thread"]
            thread.start()
        # Manage main game loop
        time_start = time()
        while True:
            # Check if all alive threads have made their moves
            moved_count = sum(1 if p["did_move"] else 0 for p in self.players)
            alive_count = sum(1 if self.bot_is_alive(p) else 0 for p in self.players)
            all_moved = moved_count == alive_count
            # print(moved_count, 'moved vs', alive_count, 'alive')
            # Check how long the game has been waiting for moves on this turn
            time_elapsed = time() - time_start
            if all_moved:
                # Update game state, cleanup player states
                self.update_state()
                # Release threads to make their next moves
                self.move_flag.set()
                self.move_flag.clear()
                # Reset the timer for moves for the next turn
                time_start = time()
            elif time_elapsed > self.bot_timelimit:
                for p in self.players:
                    if not p["did_move"] and self.bot_is_alive(p):
                        # Bots who do not move in time can no longer play
                        p["is_playing"] = False
                        slow_msg = (
                            "Player {} was slow to respond and shut down on turn {}."
                        )
                        print(slow_msg.format(p["pid"], p["turn"]))
            # Check if all threads have finished
            if alive_count == 0:
                self.move_flag.set()
                return
            # Check if max turns have been exceeded:
            turn = max(p["turn"] for p in self.players)
            if turn >= self.max_turns:
                self.move_flag.set()
                return

    def bot_is_alive(self, bot):
        return bot["thread"].is_alive() and bot["is_playing"]

    def check_assertions(self):
        fatal_error = False
        # Check that all active players are on the same turn
        max_turn = max(p["turn"] for p in self.players)
        for p in self.players:
            active = self.bot_is_alive(p)
            same_turn = p["turn"] == max_turn
            if active:
                # assert same_turn
                if not same_turn:
                    fatal_error = True
                    print("Error: The players are no longer on the same turn number.")
        # Check that no players share the same position
        for pid, player in enumerate(self.players):
            for o_pid, o_player in enumerate(self.players):
                if pid is not o_pid:
                    same_pos = player["position"] == o_player["position"]
                    # assert not same_pos
                    if same_pos:
                        fatal_error = True
                        print("Error: Multiple players are on the same space.")
        if fatal_error:
            exit("Game could not be completed due to errors in the Paintbot module.")

    def update_state(self):
        # Compute desired destination for each player
        destination = [p["position"] for p in self.players]
        for p in self.players:
            if p["did_move"]:
                # Inspect move and state of player
                # print('Turn', p['turn'], 'Player', p['pid'], '->', p['move'])
                # Copy position value
                pid = p["pid"]
                pos = list(p["position"])
                d = p["move"]
                pos = self.get_new_position(pos, d)
                # Check if position is in bounds
                if not self.is_in_bounds(pos[0], pos[1]):
                    p["move_failed"] = True
                # Check if cell exists
                if not self.is_missing(pos[0], pos[1]):
                    p["move_failed"] = True
                destination[pid] = pos
        # Update destinations based on invalid moves
        new_dests = self.get_destinations(destination)
        # Update player positions and paint board
        for pid, dest in enumerate(new_dests):
            # Only persist successful moves
            if not self.players[pid]["move_failed"]:
                self.players[pid]["position"] = dest
                self.board[dest[1]][dest[0]] = str(pid)
            else:
                # print(pid, dest, self.players[pid]['turn'])
                pass
        self.update_record(destination)
        # Reset player fields
        for p in self.players:
            p["move"] = None
            p["did_move"] = False
            p["move_failed"] = False
        self.check_assertions()

    def get_destinations(self, destination):
        new_dests = self.prevent_mobile_collisions(destination)
        new_dests = self.prevent_stable_collisions(new_dests)
        return new_dests

    def prevent_mobile_collisions(self, destination):
        # First pass
        new_dests = list(destination)
        for pid, player in enumerate(self.players):
            pos = player["position"]
            dest = destination[pid]
            for o_pid, o_player in enumerate(self.players):
                o_pos = o_player["position"]
                o_dest = destination[o_pid]
                if pid is not o_pid:
                    # Check for same space
                    if dest == o_dest:
                        new_dests[pid] = pos
                        new_dests[o_pid] = o_pos
                        self.players[pid]["move_failed"] = True
                        self.players[o_pid]["move_failed"] = True
                    # Check for pass throughs
                    if (dest == o_pos) and (o_dest == pos):
                        new_dests[pid] = pos
                        new_dests[o_pid] = o_pos
                        self.players[pid]["move_failed"] = True
                        self.players[o_pid]["move_failed"] = True
        return new_dests

    def prevent_stable_collisions(self, new_dests):
        # Second pass
        for pid, player in enumerate(self.players):
            pos = player["position"]
            dest = new_dests[pid]
            still = dest == pos
            if not still:
                for o_pid, o_player in enumerate(self.players):
                    o_pos = o_player["position"]
                    o_dest = new_dests[o_pid]
                    o_still = o_dest == o_pos
                    if (pid is not o_pid) and (o_still):
                        # Check for movement into occupied space
                        if dest == o_pos:
                            new_dests[pid] = pos
                            self.players[pid]["move_failed"] = True
        return new_dests

    def get_new_position(self, pos, d):
        if d is not None:
            if d is "up":
                pos[1] = pos[1] - 1
            if d is "down":
                pos[1] = pos[1] + 1
            if d is "left":
                pos[0] = pos[0] - 1
            if d is "right":
                pos[0] = pos[0] + 1
        return pos

    def is_in_bounds(self, x, y):
        x_legal = x >= 0 and x < len(self.board[0])
        y_legal = y >= 0 and y < len(self.board)
        if x_legal and y_legal:
            return True

    def is_missing(self, x, y):
        if self.is_in_bounds(x, y):
            return self.board[y][x] != MISSING_CELL
        else:
            return True

    def is_free(self, x, y):
        if self.is_in_bounds(x, y):
            pos = [x, y]
            for p in self.players:
                if p["position"] == pos:
                    return False
            return self.is_missing(x, y)
        else:
            return False

    def is_valid_cell(self, cell):
        is_special = cell is MISSING_CELL or cell is OPEN_CELL
        is_colored = False
        if cell.isnumeric():
            val = int(cell)
            is_colored = (val >= 0) and (val < len(self.players))
        is_valid = is_special or is_colored
        return is_valid

    def submit_move(self, pid, direction, rotations):
        rot_str = "_".join([str(r) for r in rotations])
        player = self.players[pid]
        player["turn"] = player["turn"] + 1
        # Inspect that player turn is consistent with game turn
        # print('Turn %d: move by player %d, %s' % (player['turn'], pid, direction))
        self.players[pid]["move"] = direction
        self.players[pid]["did_move"] = True
        self.players[pid]["rotation_log"] = rot_str
        # Wait for other players to move
        self.move_flag.wait()

    def print_board(self):
        output = ""
        for row in self.board:
            for cell in row:
                cell_rep = cell
                if cell is MISSING_CELL:
                    cell_rep = " "
                output = output + str(cell_rep) + " "
            output = output + "\n"
        print(output)

    def get_scores(self):
        scores = [0 for p in self.players]
        for row in self.board:
            for cell in row:
                if cell.isnumeric():
                    pid = int(cell)
                    scores[pid] = scores[pid] + 1
        return scores

    def get_winners(self):
        winners = []
        high_score = max(self.get_scores())
        for pid, score in enumerate(self.get_scores()):
            if score == high_score:
                winners.append(pid)
        return winners

    def get_turn(self):
        return max(p["turn"] for p in self.players)

    def update_record(self, destination):
        self.record = self.record + ","
        last = len(self.players) - 1
        for pid, player in enumerate(self.players):
            pos = player["position"]
            rot = player["rotation_log"]
            failed = player["move_failed"]
            pos_rec = "{}_{}_{}_{}".format(pid, pos[0], pos[1], rot)
            if failed:
                dest = destination[pid]
                pos_rec = "{}_{}_{}_{}_f".format(pid, dest[0], dest[1], rot)
            if pid is not last:
                pos_rec = pos_rec + "!"
            self.record = self.record + pos_rec
            player["rotation_log"] = str(player["bot"].get_rotation())

    def get_record(self):
        return self.record

    def get_board_record(self):
        record = ""
        for y, row in enumerate(self.board):
            for x, cell in enumerate(row):
                if cell is MISSING_CELL:
                    record += "{}_{}_{}!".format(x, y, "x")
                elif cell is not OPEN_CELL:
                    record += "{}_{}_{}!".format(x, y, cell)
        return record
