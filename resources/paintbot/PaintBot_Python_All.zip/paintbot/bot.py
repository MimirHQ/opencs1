"""
Player Class for PaintBot
"""


class PaintBot:
    """Manages player state and accesses game data"""

    __pid = None
    __game = None
    __rotation = 0
    __iostarted = False
    __rotation_log = [0]

    def __init__(self, game, pid, rotation=0):
        self.__game = game
        self.__pid = pid
        self.__rotation = rotation
        self.__iostarted = False
        self.__rotation_log = [rotation]

    """Game State Managers"""

    def get_board_data(self):
        board = self.__game.board
        cells = []
        for row in board:
            for cell in row:
                if cell is "_":
                    cells.append("x")
                else:
                    cells.append(cell)
        for p in self.__game.players:
            pos = p["position"]
            x = pos[0]
            y = pos[1]
            x_size = self.get_x_size()
            index = (y * x_size) + x
            cells[index] = "^{}".format(cells[index])
        data = ",".join(cells)
        return data

    def start(self):
        self.__iostarted = True

    def did_start_io(self):
        return self.__iostarted

    def __get_and_flush_rotation_log(self):
        rot_log = list(self.__rotation_log)
        self.__rotation_log = [self.__rotation]
        return rot_log

    def __up(self):
        rot_log = self.__get_and_flush_rotation_log()
        self.__game.submit_move(self.__pid, "up", rot_log)

    def __down(self):
        rot_log = self.__get_and_flush_rotation_log()
        self.__game.submit_move(self.__pid, "down", rot_log)

    def __left(self):
        rot_log = self.__get_and_flush_rotation_log()
        self.__game.submit_move(self.__pid, "left", rot_log)

    def __right(self):
        rot_log = self.__get_and_flush_rotation_log()
        self.__game.submit_move(self.__pid, "right", rot_log)

    def get_pid(self):
        return int(self.__pid)

    """Movement"""

    def forward(self):
        angle = self.__rotation
        if angle == 0:
            self.__up()
        elif angle == 90:
            self.__right()
        elif angle == 180:
            self.__down()
        else:
            self.__left()

    def backward(self):
        angle = self.__rotation
        if angle == 0:
            self.__down()
        elif angle == 90:
            self.__left()
        elif angle == 180:
            self.__up()
        else:
            self.__right()

    def rotate_right(self):
        new_rotation = (self.__rotation + 90) % 360
        self.__rotation = new_rotation
        self.__rotation_log.append(self.__rotation)

    def rotate_left(self):
        new_rotation = self.__rotation - 90
        if new_rotation < 0:
            new_rotation = new_rotation + 360
        self.__rotation = new_rotation
        self.__rotation_log.append(self.__rotation)

    def skip(self):
        rot_log = self.__get_and_flush_rotation_log()
        self.__game.submit_move(self.__pid, "skip", rot_log)

    """Sensors"""

    def get_rotation(self):
        return self.__rotation

    def get_x(self):
        return list(self.__game.players[self.__pid]["position"])[0]

    def get_y(self):
        return list(self.__game.players[self.__pid]["position"])[1]

    def get_x_size(self):
        return len(self.__game.board[0])

    def get_y_size(self):
        return len(self.__game.board)

    def is_in_bounds(self, x, y):
        return self.__game.is_in_bounds(x, y)

    def is_blocked(self):
        ahead = (self.get_x(), self.get_y())
        angle = self.__rotation
        if angle == 0:
            ahead[1] = ahead[1] - 1
        elif angle == 90:
            ahead[0] = ahead[0] + 1
        elif angle == 180:
            ahead[1] = ahead[1] + 1
        else:
            ahead[0] = ahead[0] - 1
        return not self.__game.is_free(ahead[0], ahead[1])

    def is_my_color(self, x, y):
        board = self.__game.board
        if self.__game.is_in_bounds(x, y):
            cell = board[y][x]
            if cell is ".":
                return False
            if cell is " ":
                return False
            return int(cell) == self.__pid
        return False

    """Game Data"""

    def get_my_score(self):
        return int(self.__game.get_scores()[self.__pid])

    def get_turn(self):
        return int(self.__game.players[self.__pid]["turn"])

    def get_max_turns(self):
        return int(self.__game.max_turns)

    def is_playing(self):
        return self.get_turn() < self.__game.max_turns
