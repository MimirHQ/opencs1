"""
global vars for paintbot
"""

__version__ = "0.0.1"


BOT_TIMELIMIT = 4
BOT_TIMEOUT_MESSAGE = "Bot timed out!"
