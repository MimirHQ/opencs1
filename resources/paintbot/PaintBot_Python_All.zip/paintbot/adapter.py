import time
import shlex
from subprocess import Popen, PIPE, TimeoutExpired  # nosec
from threading import Thread


def create_board(rows, columns):
    """creates a board for the game"""
    return [["." for y in range(columns)] for x in range(rows)]


def create_board_from_file(filename):
    with open(filename, "r") as file:
        read_lines = [line.lstrip().rstrip() for line in file.read().split("\n")]
        all_lines = [line for line in read_lines if len(line) > 0]
        turns = None
        initials = []
        lines = []
        for line in all_lines:
            is_comment = line[0] == "#" or line[0:2] == "//"
            if turns is None and line.isnumeric():
                turns = int(line)
                is_comment = True
            if line[0] == "P":
                init = [int(val.lstrip().rstrip()) for val in line.split(",")[1:]]
                if init[2] in [0, 90, 180, 270]:
                    initials.append(init)
                is_comment = True
            if not is_comment:
                lines.append(line)
        board = [row.split(" ") for row in lines]
        if len(initials) == 0:
            initials = None
        return (board, turns, initials)


def write_game_state(bot, proc):
    if proc.poll() is None:
        board_data = bot.get_board_data()
        color = bot.get_pid()
        xp = bot.get_x()
        yp = bot.get_y()
        rot = bot.get_rotation()
        xs = bot.get_x_size()
        ys = bot.get_y_size()
        turn = bot.get_turn()
        max_turns = bot.get_max_turns()
        my_score = bot.get_my_score()
        res_data = [color, xs, ys, xp, yp, rot, turn, max_turns, my_score, board_data]
        res = "\n".join([str(d) for d in res_data])
        res_str = str(res) + "\n"
        # print(bot.get_pid(), 'update', res_str)
        proc.stdin.write(res_str.encode("utf-8"))
        proc.stdin.flush()


def parse_cmd(bot, cmd, data, val):
    bot_fn = None
    res = None
    if cmd == "start":
        bot.start()
    elif cmd == "get_board_data":
        pass
    elif cmd == "forward":
        bot_fn = bot.forward
    elif cmd == "backward":
        bot_fn = bot.backward
    elif cmd == "rotate_left":
        bot.rotate_left()
    elif cmd == "rotate_right":
        bot.rotate_right()
    elif cmd == "skip":
        bot_fn = bot.skip
    else:
        # skip turn?
        res = "Error: Invalid command ({})".format(val)
    if res:
        res = str(res)  # nosec
    return res, bot_fn


def execute_bot(run_args):
    proc = Popen(shlex.split(run_args), stdin=PIPE, stdout=PIPE, stderr=PIPE, bufsize=1)
    return proc


def read_next_move(bot, proc, results, i):
    if not proc:
        results[i] = None
        return
    while True:
        line = None
        if proc.poll() is None:
            line = proc.stdout.readline().rstrip()
        if line:
            val = line.decode("utf-8")
            # print(bot.get_pid(), 'read', val)
            if val.find("cmd:") == 0:
                data = val.split("cmd:")[1].split(",")
                cmd = data[0]
                res, bot_fn = parse_cmd(bot, cmd, data, val)
                if bot_fn:
                    results[i] = (cmd, data, bot_fn)
                    return
                elif res:
                    if proc.poll() is None:
                        res_str = str(res) + "\n"
                        # print(bot.get_pid(), 'write', res_str)
                        proc.stdin.write(res_str.encode("utf-8"))
                        proc.stdin.flush()
            else:
                print(val)
        else:
            results[i] = ("end", [])
            return


def get_next_move(bot, proc, results, i, timeout):
    if not proc:
        return False
    t = Thread(target=read_next_move, args=(bot, proc, results, i), daemon=True)
    s = time.time()
    t.start()
    while True:
        if results[i] is not None:
            return True
        if (time.time() - s) > timeout:
            return False


def end_proc(proc, quiet=False):
    if proc:
        try:
            out, err = proc.communicate(b"\n", timeout=1)
            if not quiet:
                if out:
                    print(out.decode("utf-8"))
                if err:
                    print(err.decode("utf-8"))
        except TimeoutExpired:
            proc.kill()


def create_bot(run_args, timeout):
    def run_bot(bot):
        proc = execute_bot(run_args)
        write_game_state(bot, proc)
        playing = True
        while playing:
            moves = [None]
            get_next_move(bot, proc, moves, 0, timeout)
            move = moves[0]
            if not move:
                pid = bot.get_pid()
                turn = bot.get_turn()
                print(
                    "Player {} was slow to respond and shut down on turn {}.".format(
                        pid, turn
                    )
                )
                end_proc(proc)
                return
            if move[0] == "end":
                end_proc(proc)
                return
            if len(move) >= 3:
                if move[2]:
                    if bot.did_start_io():
                        bot_fn = move[2]
                        bot_fn()
                        write_game_state(bot, proc)
                    else:
                        pid = bot.get_pid()
                        print("Player {} never called the start() method.".format(pid))
                        end_proc(proc, quiet=True)
                        return

    return run_bot
