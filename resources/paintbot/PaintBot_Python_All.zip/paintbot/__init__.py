"""
paintbot main module
"""
from paintbot.game import PaintGame  # noqa
from paintbot.adapter import create_bot, create_board, create_board_from_file  # noqa
