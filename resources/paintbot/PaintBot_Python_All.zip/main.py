"""
This sample game uses bots written in different languages.
"""
import time
from paintbot import PaintGame, create_board_from_file
from p0 import main as p0_main
from p1 import main as p1_main


def main():
    """main run method"""
    BOT_TIMEOUT = 8
    MAX_TURNS = 25
    MAP_FILE = "map.txt"
    PLAYER0 = p0_main
    PLAYER1 = p1_main
    board, turns, initials = create_board_from_file(MAP_FILE)
    cols = len(board[0])
    rows = len(board)
    pd = [(0, 0, 90), (cols - 1, rows - 1, 270)]
    if turns:
        MAX_TURNS = turns
    if initials:
        pd = initials
    game = PaintGame(max_turns=MAX_TURNS, bot_timelimit=BOT_TIMEOUT, board=board)
    game.add_player(PLAYER0, [pd[0][0], pd[0][1]], pd[0][2])
    game.add_player(PLAYER1, [pd[1][0], pd[1][1]], pd[1][2])
    board_record = game.get_board_record()
    start = time.time()
    game.start()
    dur = time.time() - start
    print()
    game.print_board()
    print("Final Score:", game.get_scores())
    print("Winners:", game.get_winners())
    record = game.get_record()
    print("https://paintbot.glitch.me?s={}&b={}".format(record, board_record))
    print("Ran in {0:.3f} secs".format(dur))
    p0_won = 0 in game.get_winners()
    solo_win = len(game.get_winners()) == 1
    if p0_won and solo_win:
        with open("OUTPUT", "w") as f:
            f.write("100")


if __name__ == "__main__":
    main()
