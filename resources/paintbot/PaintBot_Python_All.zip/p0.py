def main(bot):
    # TODO: Program your bot here
    pass
